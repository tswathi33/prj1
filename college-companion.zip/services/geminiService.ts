
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { ChatMessage } from "../types";

// Fix: Always use the prescribed initialization pattern and use process.env.API_KEY directly.
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
You are the "JNTUH Companion AI", a specialized academic expert for Jawaharlal Nehru Technological University Hyderabad.
Your Core Knowledge:
1. JNTUH Regulations: R18, R22, R23. You know promotion rules, detention rules, and credit systems.
2. Syllabus: Branch-wise (CSE, IT, ECE, EEE, CIVIL, MECH).
3. Student Context: Help with GPA calculations, exam preparation, and navigating JNTUH notifications.

Communication Style:
- Use "Telish" (Telugu + English) for student queries when requested (e.g., "M1 result eppudu vastundi?").
- For complex logic (e.g., "Am I eligible for 3rd year?"), use THINKING mode to calculate credits correctly.
- Provide study plans based on the JNTUH syllabus units.

Rules:
- If asked about results, use Search grounding.
- If asked about college locations, use Maps grounding.
- Promotion Rules: Be very strict based on JNTUH R18/R22 guidelines.
`;

export const getSmartResponse = async (
  message: string, 
  history: ChatMessage[], 
  options: { 
    useThinking?: boolean; 
    useSearch?: boolean; 
    useMaps?: boolean;
    media?: { mimeType: string; data: string }[];
  } = {}
) => {
  const ai = getAI();
  // Fix: Using recommended model names for task types. Basic text tasks use gemini-3-flash-preview.
  const model = (options.useThinking || options.media?.length || options.useSearch) 
    ? 'gemini-3-pro-preview' 
    : 'gemini-3-flash-preview';
  
  const contents: any = [
    ...history.slice(-8).map(m => ({
      role: m.role,
      parts: [{ text: m.text }]
    })),
    {
      role: 'user',
      parts: [
        { text: message || "Explain JNTUH promotion rules." },
        ...(options.media || []).map(m => ({ inlineData: m }))
      ]
    }
  ];

  const config: any = {
    systemInstruction: SYSTEM_INSTRUCTION,
    tools: [],
  };

  if (options.useThinking && (model === 'gemini-3-pro-preview')) {
    config.thinkingConfig = { thinkingBudget: 32768 };
  }
  if (options.useSearch) config.tools.push({ googleSearch: {} });
  if (options.useMaps) config.tools.push({ googleMaps: {} });

  const result = await ai.models.generateContent({
    model,
    contents,
    config
  });

  const urls: { title: string; uri: string }[] = [];
  result.candidates?.[0]?.groundingMetadata?.groundingChunks?.forEach((chunk: any) => {
    if (chunk.web) urls.push({ title: chunk.web.title, uri: chunk.web.uri });
  });

  return {
    text: result.text || "",
    groundingUrls: urls.length > 0 ? urls : undefined
  };
};

export const analyzeJNTUHNotification = async (file: File) => {
  const ai = getAI();
  const media = await fileToDataPart(file);
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: [{
      parts: [
        { inlineData: media },
        { text: "Analyze this JNTUH notification. Extract: 1. Event Type (Result/Fee/Holiday). 2. Key Dates. 3. Eligibility. 4. Fee details (if any). Explain in simple Telugu + English." }
      ]
    }],
    config: { thinkingConfig: { thinkingBudget: 32768 } }
  });
  return response.text || "Failed to analyze notification.";
};

// Fix: Added missing summarizeAcademicContent function to resolve import error in AILab.tsx
export const summarizeAcademicContent = async (file: File) => {
  const ai = getAI();
  const media = await fileToDataPart(file);
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: [{
      parts: [
        { inlineData: media },
        { text: "Analyze and summarize this academic document. Provide a detailed summary including main topics, sub-points, and key takeaways useful for university students." }
      ]
    }],
    config: { thinkingConfig: { thinkingBudget: 32768 } }
  });
  return response.text || "Failed to analyze document.";
};

export const fileToDataPart = async (file: File) => {
  return new Promise<{ mimeType: string; data: string }>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const base64Data = (reader.result as string).split(',')[1];
      resolve({ mimeType: file.type, data: base64Data });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

export const generateSpeech = async (text: string): Promise<string> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } } },
    },
  });
  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || "";
};

export const transcribeAudio = async (audioData: string): Promise<string> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [{
      parts: [
        { inlineData: { mimeType: 'audio/wav', data: audioData } },
        { text: "Transcribe this student query or lecture segment. Focus on JNTUH academic terms." }
      ]
    }]
  });
  return response.text || "";
};

export const generateImage = async (prompt: string, size: "1K" | "2K" | "4K" = "1K"): Promise<string> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: { parts: [{ text: prompt }] },
    config: { imageConfig: { aspectRatio: "1:1", imageSize: size } },
  });
  const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
  return part?.inlineData?.data ? `data:image/png;base64,${part.inlineData.data}` : "";
};
