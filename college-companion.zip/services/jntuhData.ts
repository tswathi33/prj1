
import { JNTUHRegulation, JNTUHSubject } from '../types';

export const JNTUH_REGULATIONS: JNTUHRegulation[] = [
  {
    code: 'R22',
    name: 'B.Tech R22 Regulations (CBCS)',
    totalCredits: 160,
    promotionRules: {
      toYear2: "Must secure at least 50% credits from 1st year (20/40 credits approximately).",
      toYear3: "Must secure at least 60% credits from 1st and 2nd year combined.",
      toYear4: "Must secure at least 60% credits from 1st, 2nd, and 3rd year combined."
    },
    attendanceRule: "Minimum 75% attendance. Condonation (65-75%) allowed with medical certificate and fee.",
    graceMarks: "Up to 0.25% of total marks in the final year for passing subjects."
  },
  {
    code: 'R18',
    name: 'B.Tech R18 Regulations',
    totalCredits: 160,
    promotionRules: {
      toYear2: "Secured at least 18 credits out of 37 credits in 1st year.",
      toYear3: "Secured at least 47 credits out of 79 credits up to 2nd year.",
      toYear4: "Secured at least 73 credits out of 121 credits up to 3rd year."
    },
    attendanceRule: "75% Mandatory. Below 65% is detention.",
    graceMarks: "Exemption of two subjects allowed for degree if credits are maintained."
  }
];

export const SYLLABUS_DATABASE: Record<string, Record<string, JNTUHSubject[]>> = {
  'CSE': {
    '2-1': [
      {
        code: 'CS301PC',
        name: 'Data Structures',
        credits: 3,
        units: [
          { unitNumber: 1, title: 'Introduction to Data Structures', topics: ['Abstract Data Types', 'Asymptotic Notations', 'Stacks', 'Queues'] },
          { unitNumber: 2, title: 'Dictionaries & Hash Tables', topics: ['Hashing', 'Collision Resolution', 'Linear Probing', 'Double Hashing'] }
        ],
        textbooks: ['Fundamentals of Data Structures in C - Ellis Horowitz'],
        references: ['Data Structures using C - Reema Thareja']
      },
      {
        code: 'CS302PC',
        name: 'Computer Organization & Architecture',
        credits: 3,
        units: [
          { unitNumber: 1, title: 'Basic Structure of Computers', topics: ['Instruction Sequencing', 'Addressing Modes', 'CPU Design'] }
        ],
        textbooks: ['Computer Organization - Carl Hamacher'],
        references: ['Structured Computer Organization - Tanenbaum']
      }
    ]
  }
};
