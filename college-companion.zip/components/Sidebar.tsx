
import React from 'react';
import { UserRole } from '../types';

interface SidebarProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  role: UserRole;
  isOpen: boolean;
  toggleSidebar: () => void;
  onNewTask?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setCurrentView, role, isOpen, toggleSidebar, onNewTask }) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'fa-chart-line', roles: [UserRole.STUDENT, UserRole.FACULTY, UserRole.ADMIN] },
    { id: 'jntuh', label: 'JNTUH Hub', icon: 'fa-university', roles: [UserRole.STUDENT, UserRole.FACULTY] },
    { id: 'ailab', label: 'AI Lab', icon: 'fa-vial', roles: [UserRole.STUDENT, UserRole.FACULTY] },
    { id: 'timetable', label: 'Timetable', icon: 'fa-calendar-alt', roles: [UserRole.STUDENT, UserRole.FACULTY] },
    { id: 'tasks', label: 'Personal Tasks', icon: 'fa-clipboard-list', roles: [UserRole.STUDENT, UserRole.FACULTY] },
    { id: 'attendance', label: 'Attendance', icon: 'fa-user-check', roles: [UserRole.STUDENT, UserRole.FACULTY] },
    { id: 'notices', label: 'Notices', icon: 'fa-bullhorn', roles: [UserRole.STUDENT, UserRole.FACULTY, UserRole.ADMIN] },
    { id: 'materials', label: 'Materials', icon: 'fa-book-open', roles: [UserRole.STUDENT, UserRole.FACULTY] },
    { id: 'map', label: 'Campus Map', icon: 'fa-map-marked-alt', roles: [UserRole.STUDENT, UserRole.FACULTY, UserRole.ADMIN] },
    { id: 'profile', label: 'Settings', icon: 'fa-gear', roles: [UserRole.STUDENT, UserRole.FACULTY, UserRole.ADMIN] },
  ];

  return (
    <aside className={`bg-[#e9eef6] text-[#1f1f1f] h-screen transition-all duration-300 ease-in-out flex flex-col z-50 ${isOpen ? 'w-64' : 'w-20'} border-r border-transparent`}>
      <div className="p-4 flex items-center h-16 mb-4">
        <button onClick={toggleSidebar} className="w-12 h-12 flex items-center justify-center rounded-full hover:bg-[#dde3ea] transition-colors">
          <i className="fas fa-bars text-xl text-[#444746]"></i>
        </button>
        {isOpen && (
          <div className="ml-2 flex items-center gap-2 animate-fadeIn overflow-hidden whitespace-nowrap">
            <i className="fas fa-graduation-cap text-indigo-600 text-2xl"></i>
            <span className="font-bold text-lg tracking-tight text-[#1f1f1f]">Companion</span>
          </div>
        )}
      </div>

      <div className="px-3 mb-6">
        <button onClick={onNewTask} className={`flex items-center gap-3 bg-[#c2e7ff] text-[#001d35] rounded-2xl transition-all duration-300 overflow-hidden ${isOpen ? 'px-4 py-4 w-full shadow-sm' : 'p-4 w-12 mx-auto justify-center'} hover:shadow-md active:scale-95`}>
          <i className="fas fa-plus text-lg"></i>
          {isOpen && <span className="font-bold whitespace-nowrap">New Task</span>}
        </button>
      </div>

      <nav className="flex-1 px-3 overflow-y-auto overflow-x-hidden space-y-1">
        {navItems.filter(item => item.roles.includes(role)).map((item) => (
          <button key={item.id} onClick={() => setCurrentView(item.id)} className={`flex items-center gap-4 rounded-full transition-all duration-200 group relative ${isOpen ? 'px-4 py-3 w-full' : 'p-4 w-12 mx-auto justify-center'} ${currentView === item.id ? 'bg-[#d3e3fd] text-[#041e49] font-bold' : 'text-[#444746] hover:bg-[#dde3ea]'}`}>
            <i className={`fas ${item.icon} w-5 text-center text-lg`}></i>
            {isOpen && <span className="text-sm whitespace-nowrap flex-1 text-left animate-fadeIn">{item.label}</span>}
            {!isOpen && <div className="absolute left-full ml-4 px-2 py-1 bg-gray-800 text-white text-[10px] rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-50">{item.label}</div>}
          </button>
        ))}
      </nav>

      <div className="p-4 space-y-2">
        <div onClick={() => setCurrentView('profile')} className={`flex items-center gap-3 p-2 rounded-full hover:bg-[#dde3ea] cursor-pointer transition-colors ${!isOpen && 'justify-center'}`}>
          <div className="w-8 h-8 rounded-full bg-indigo-500 overflow-hidden shrink-0 border border-white">
             <img src={`https://picsum.photos/seed/${role}/100/100`} alt="Profile" className="w-full h-full object-cover" />
          </div>
          {isOpen && (
            <div className="animate-fadeIn overflow-hidden">
              <p className="text-xs font-bold text-[#1f1f1f] truncate">Alex Thompson</p>
              <p className="text-[10px] text-gray-500 font-bold uppercase">{role}</p>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
