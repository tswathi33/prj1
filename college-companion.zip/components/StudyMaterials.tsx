
import React, { useState } from 'react';
import { MOCK_MATERIALS } from '../constants';

const StudyMaterials: React.FC = () => {
  const [regFilter, setRegFilter] = useState<'All' | 'R18' | 'R22'>('All');
  const [semFilter, setSemFilter] = useState('All');
  const [catFilter, setCatFilter] = useState('All');

  const filteredMaterials = MOCK_MATERIALS.filter(m => {
    const matchReg = regFilter === 'All' || m.regulation === regFilter;
    const matchSem = semFilter === 'All' || m.semester === semFilter;
    const matchCat = catFilter === 'All' || m.category === catFilter;
    return matchReg && matchSem && matchCat;
  });

  const semesters = ['All', '1-1', '1-2', '2-1', '2-2', '3-1', '3-2', '4-1', '4-2'];
  const categories = ['All', 'Notes', 'Syllabus', 'Question Papers', 'Textbooks'];

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Database Filters */}
      <div className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm space-y-4">
        <h2 className="text-sm font-black text-gray-800 uppercase tracking-widest flex items-center gap-2">
          <i className="fas fa-filter text-indigo-600"></i>
          Database Filters
        </h2>
        <div className="flex flex-wrap gap-4">
          <div className="flex-1 min-w-[150px]">
            <label className="block text-[10px] font-black text-gray-400 uppercase mb-1.5 ml-1">Regulation</label>
            <select 
              value={regFilter} 
              onChange={(e) => setRegFilter(e.target.value as any)}
              className="w-full bg-gray-50 border-none rounded-2xl px-4 py-3 text-sm font-bold text-gray-700 outline-none focus:ring-2 focus:ring-indigo-100"
            >
              <option value="All">All Regulations</option>
              <option value="R22">JNTUH R22</option>
              <option value="R18">JNTUH R18</option>
            </select>
          </div>
          <div className="flex-1 min-w-[150px]">
            <label className="block text-[10px] font-black text-gray-400 uppercase mb-1.5 ml-1">Semester</label>
            <select 
              value={semFilter} 
              onChange={(e) => setSemFilter(e.target.value)}
              className="w-full bg-gray-50 border-none rounded-2xl px-4 py-3 text-sm font-bold text-gray-700 outline-none focus:ring-2 focus:ring-indigo-100"
            >
              {semesters.map(s => <option key={s} value={s}>{s === 'All' ? 'All Semesters' : `Semester ${s}`}</option>)}
            </select>
          </div>
          <div className="flex-1 min-w-[150px]">
            <label className="block text-[10px] font-black text-gray-400 uppercase mb-1.5 ml-1">Category</label>
            <select 
              value={catFilter} 
              onChange={(e) => setCatFilter(e.target.value)}
              className="w-full bg-gray-50 border-none rounded-2xl px-4 py-3 text-sm font-bold text-gray-700 outline-none focus:ring-2 focus:ring-indigo-100"
            >
              {categories.map(c => <option key={c} value={c}>{c === 'All' ? 'All Types' : c}</option>)}
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMaterials.map(item => (
          <div key={item.id} className="bg-white p-5 rounded-[28px] border border-gray-100 shadow-sm group hover:-translate-y-1 transition-all relative overflow-hidden">
            {item.regulation && (
              <div className="absolute top-0 right-0 px-3 py-1 bg-indigo-600 text-white text-[9px] font-black rounded-bl-xl shadow-sm">
                {item.regulation}
              </div>
            )}
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                item.category === 'Syllabus' ? 'bg-indigo-50 text-indigo-600' :
                item.type === 'PDF' ? 'bg-rose-50 text-rose-600' :
                item.type === 'PPT' ? 'bg-amber-50 text-amber-600' :
                'bg-blue-50 text-blue-600'
              }`}>
                <i className={`fas ${
                  item.category === 'Syllabus' ? 'fa-book-atlas' :
                  item.type === 'PDF' ? 'fa-file-pdf' :
                  item.type === 'PPT' ? 'fa-file-powerpoint' :
                  'fa-file-word'
                } text-xl`}></i>
              </div>
              <span className="text-[10px] font-bold text-gray-400 bg-gray-50 px-2 py-1 rounded-lg uppercase">{item.size}</span>
            </div>
            
            <h3 className="font-bold text-gray-800 mb-1 leading-tight h-10 overflow-hidden line-clamp-2">{item.title}</h3>
            <div className="flex items-center gap-2 mb-4">
              <span className="text-[10px] font-black text-indigo-500 bg-indigo-50 px-2 py-0.5 rounded uppercase tracking-tighter">
                Sem {item.semester}
              </span>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tight truncate">{item.subject}</p>
            </div>

            <div className="flex items-center justify-between mt-auto">
              <div className="flex flex-col">
                <span className="text-[10px] text-gray-300 font-bold uppercase tracking-widest">{item.category}</span>
                <span className="text-[10px] text-gray-400">{item.uploadedDate}</span>
              </div>
              <button className="bg-indigo-600 text-white w-10 h-10 rounded-xl flex items-center justify-center hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 active:scale-90">
                <i className="fas fa-download text-xs"></i>
              </button>
            </div>
          </div>
        ))}

        {/* Upload Card for Faculty */}
        <div className="border-2 border-dashed border-indigo-100 rounded-[28px] flex flex-col items-center justify-center p-8 bg-indigo-50/20 group cursor-pointer hover:bg-indigo-50 transition-colors">
          <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center text-indigo-600 shadow-sm mb-4 transition-transform group-hover:scale-110">
            <i className="fas fa-plus"></i>
          </div>
          <p className="font-bold text-indigo-600 text-sm">Contribute Material</p>
          <p className="text-[10px] text-indigo-300 mt-1 uppercase font-black tracking-widest">Help your peers</p>
        </div>
      </div>

      {filteredMaterials.length === 0 && (
        <div className="text-center py-20 bg-white rounded-[40px] border border-gray-100">
           <i className="fas fa-search-minus text-4xl text-gray-200 mb-4"></i>
           <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">No records found for this combination.</p>
        </div>
      )}
    </div>
  );
};

export default StudyMaterials;
