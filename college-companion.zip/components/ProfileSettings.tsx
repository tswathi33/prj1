
import React, { useState } from 'react';
import { UserRole } from '../types';

const ProfileSettings: React.FC<{ role: UserRole }> = ({ role }) => {
  const [formData, setFormData] = useState({
    name: 'Alex Thompson',
    email: 'alex.t@university.edu',
    dept: 'Computer Science & Engineering',
    semester: '6th Semester',
    studentId: 'CS2021045',
    notifications: true,
    darkMode: false,
    publicProfile: true,
    aiPersonalization: true
  });

  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success'>('idle');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    const val = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    setFormData(prev => ({ ...prev, [name]: val }));
  };

  const handleToggle = (field: string) => {
    setFormData(prev => ({ ...prev, [field]: !prev[field as keyof typeof prev] }));
  };

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      setSaveStatus('success');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }, 1200);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fadeIn pb-24">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Left Column: Profile Card & Quick Actions */}
        <div className="w-full md:w-1/3 space-y-6">
          <div className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-sm text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-br from-indigo-500 to-indigo-700"></div>
            <div className="relative pt-8">
              <div className="relative inline-block group">
                <div className="w-32 h-32 rounded-full border-4 border-white shadow-xl overflow-hidden bg-gray-100">
                  <img 
                    src={`https://picsum.photos/seed/${role}/300/300`} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <button className="absolute bottom-1 right-1 bg-indigo-600 text-white w-10 h-10 rounded-full border-4 border-white flex items-center justify-center hover:bg-indigo-700 transition-all shadow-lg active:scale-95">
                  <i className="fas fa-camera text-xs"></i>
                </button>
              </div>
              <h2 className="text-2xl font-black text-gray-900 mt-4 tracking-tight">{formData.name}</h2>
              <p className="text-indigo-600 font-bold text-sm uppercase tracking-widest mt-1">{role}</p>
              <div className="mt-6 flex flex-col gap-2">
                <div className="bg-gray-50 p-3 rounded-2xl border border-gray-100">
                  <p className="text-[10px] font-black text-gray-400 uppercase">Institutional ID</p>
                  <p className="text-sm font-bold text-gray-700">{formData.studentId}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm space-y-4">
            <h3 className="text-sm font-black text-gray-800 uppercase tracking-widest px-2">Account Links</h3>
            <button className="w-full flex items-center justify-between p-4 hover:bg-gray-50 rounded-2xl transition-all group">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                  <i className="fas fa-envelope text-xs"></i>
                </div>
                <span className="text-sm font-bold text-gray-700">Change Email</span>
              </div>
              <i className="fas fa-chevron-right text-gray-300 group-hover:text-indigo-400 transition-colors"></i>
            </button>
            <button className="w-full flex items-center justify-between p-4 hover:bg-gray-50 rounded-2xl transition-all group">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                  <i className="fas fa-key text-xs"></i>
                </div>
                <span className="text-sm font-bold text-gray-700">Change Password</span>
              </div>
              <i className="fas fa-chevron-right text-gray-300 group-hover:text-indigo-400 transition-colors"></i>
            </button>
          </div>
        </div>

        {/* Right Column: Detailed Settings */}
        <div className="flex-1 space-y-8">
          {/* General Information */}
          <section className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-sm space-y-6">
            <div className="flex items-center gap-4 border-b border-gray-50 pb-4">
              <div className="w-10 h-10 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600">
                <i className="fas fa-user-gear"></i>
              </div>
              <div>
                <h3 className="text-xl font-black text-gray-900">Personal Information</h3>
                <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">Update your profile details</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Full Name</label>
                <input 
                  type="text" 
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full bg-gray-50 border border-transparent rounded-2xl px-5 py-3.5 outline-none focus:bg-white focus:border-indigo-100 focus:ring-4 focus:ring-indigo-50/50 transition-all font-medium text-gray-700"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Email Address</label>
                <input 
                  type="email" 
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full bg-gray-50 border border-transparent rounded-2xl px-5 py-3.5 outline-none focus:bg-white focus:border-indigo-100 focus:ring-4 focus:ring-indigo-50/50 transition-all font-medium text-gray-700"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Department</label>
                <select 
                  name="dept"
                  value={formData.dept}
                  onChange={handleChange}
                  className="w-full bg-gray-50 border border-transparent rounded-2xl px-5 py-3.5 outline-none focus:bg-white focus:border-indigo-100 focus:ring-4 focus:ring-indigo-50/50 transition-all font-medium text-gray-700 appearance-none"
                >
                  <option>Computer Science & Engineering</option>
                  <option>Mechanical Engineering</option>
                  <option>Electrical Engineering</option>
                  <option>Architecture</option>
                  <option>Business Administration</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Current Semester</label>
                <select 
                  name="semester"
                  value={formData.semester}
                  onChange={handleChange}
                  className="w-full bg-gray-50 border border-transparent rounded-2xl px-5 py-3.5 outline-none focus:bg-white focus:border-indigo-100 focus:ring-4 focus:ring-indigo-50/50 transition-all font-medium text-gray-700 appearance-none"
                >
                  {[...Array(8)].map((_, i) => (
                    <option key={i}>{i + 1}{i + 1 === 1 ? 'st' : i + 1 === 2 ? 'nd' : i + 1 === 3 ? 'rd' : 'th'} Semester</option>
                  ))}
                </select>
              </div>
            </div>
          </section>

          {/* App Preferences */}
          <section className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-sm space-y-6">
            <div className="flex items-center gap-4 border-b border-gray-50 pb-4">
              <div className="w-10 h-10 bg-rose-50 rounded-2xl flex items-center justify-center text-rose-600">
                <i className="fas fa-sliders-h"></i>
              </div>
              <div>
                <h3 className="text-xl font-black text-gray-900">App Preferences</h3>
                <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">Customize your experience</p>
              </div>
            </div>

            <div className="space-y-4">
              {[
                { id: 'notifications', label: 'Push Notifications', desc: 'Receive alerts for classes and notices', icon: 'fa-bell', color: 'bg-indigo-50 text-indigo-600' },
                { id: 'darkMode', label: 'Dark Mode', desc: 'Switch to midnight interface', icon: 'fa-moon', color: 'bg-indigo-900 text-white' },
                { id: 'publicProfile', label: 'Public Visibility', desc: 'Allow peers to find your academic profile', icon: 'fa-eye', color: 'bg-emerald-50 text-emerald-600' },
                { id: 'aiPersonalization', label: 'AI Personalization', desc: 'Allow Gemini to learn your schedule habits', icon: 'fa-sparkles', color: 'bg-amber-50 text-amber-600' }
              ].map(item => (
                <div key={item.id} className="flex items-center justify-between p-4 hover:bg-gray-50 rounded-[24px] transition-all group">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${item.color}`}>
                      <i className={`fas ${item.icon} text-sm`}></i>
                    </div>
                    <div>
                      <p className="text-sm font-black text-gray-800">{item.label}</p>
                      <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tight">{item.desc}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => handleToggle(item.id)}
                    className={`w-12 h-6 rounded-full transition-all relative ${formData[item.id as keyof typeof formData] ? 'bg-indigo-600' : 'bg-gray-200'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${formData[item.id as keyof typeof formData] ? 'right-1' : 'left-1'}`}></div>
                  </button>
                </div>
              ))}
            </div>
          </section>

          <div className="flex items-center justify-end gap-4">
            <button className="px-8 py-4 rounded-[24px] font-black text-xs text-gray-400 uppercase tracking-widest hover:bg-gray-100 transition-all">
              Reset Changes
            </button>
            <button 
              onClick={handleSave}
              disabled={isSaving}
              className={`px-12 py-4 rounded-[24px] font-black text-xs text-white uppercase tracking-widest transition-all shadow-xl active:scale-95 flex items-center gap-3 ${
                saveStatus === 'success' ? 'bg-emerald-500' : 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-100'
              }`}
            >
              {isSaving ? (
                <i className="fas fa-circle-notch animate-spin"></i>
              ) : saveStatus === 'success' ? (
                <>
                  <i className="fas fa-check"></i>
                  Saved Successfully
                </>
              ) : (
                <>
                  Save Profile
                  <i className="fas fa-arrow-right"></i>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileSettings;
