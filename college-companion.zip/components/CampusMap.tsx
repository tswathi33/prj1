
import React, { useState } from 'react';

const CampusMap: React.FC = () => {
  const [selectedPin, setSelectedPin] = useState<string | null>(null);

  const locations = [
    { id: 'admin', name: 'Admin Building', x: '45%', y: '20%', icon: 'fa-building' },
    { id: 'lib', name: 'Central Library', x: '65%', y: '40%', icon: 'fa-book' },
    { id: 'sci', name: 'Science Block', x: '30%', y: '50%', icon: 'fa-flask' },
    { id: 'caf', name: 'Main Canteen', x: '20%', y: '75%', icon: 'fa-utensils' },
    { id: 'aud', name: 'Auditorium', x: '80%', y: '70%', icon: 'fa-theater-masks' },
    { id: 'gym', name: 'Sports Complex', x: '75%', y: '15%', icon: 'fa-running' },
  ];

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden h-full flex flex-col animate-fadeIn">
      <div className="p-6 border-b border-gray-100">
        <h2 className="text-xl font-bold text-gray-800">Campus Navigator</h2>
        <div className="mt-4 flex gap-2 overflow-x-auto pb-2">
          {['Academic', 'Facility', 'Sports', 'Food'].map(filter => (
            <button key={filter} className="shrink-0 px-4 py-1.5 rounded-full text-sm bg-gray-100 text-gray-600 hover:bg-indigo-600 hover:text-white transition-colors">
              {filter}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 relative bg-indigo-50 min-h-[500px] cursor-crosshair overflow-hidden">
        {/* Simple Stylized Campus Map Visualization */}
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="w-full h-full" style={{ backgroundImage: 'radial-gradient(#4f46e5 1px, transparent 0)', backgroundSize: '40px 40px' }}></div>
        </div>

        {/* The Buildings/Paths Representation */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <path d="M20,10 L80,10 L80,90 L20,90 Z" fill="transparent" stroke="#cbd5e1" strokeWidth="0.5" strokeDasharray="2,2" />
          <path d="M50,10 L50,90" stroke="#cbd5e1" strokeWidth="0.5" strokeDasharray="2,2" />
          <path d="M20,50 L80,50" stroke="#cbd5e1" strokeWidth="0.5" strokeDasharray="2,2" />
        </svg>

        {locations.map(loc => (
          <div 
            key={loc.id}
            className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer group z-10"
            style={{ left: loc.x, top: loc.y }}
            onClick={() => setSelectedPin(loc.name)}
          >
            <div className={`p-3 rounded-2xl shadow-lg transition-all transform group-hover:scale-110 group-hover:-translate-y-1 ${
              selectedPin === loc.name ? 'bg-indigo-600 text-white ring-4 ring-indigo-200' : 'bg-white text-indigo-600'
            }`}>
              <i className={`fas ${loc.icon} text-lg`}></i>
            </div>
            <div className={`absolute top-full left-1/2 -translate-x-1/2 mt-2 px-3 py-1 bg-gray-800 text-white text-[10px] font-bold rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity z-20`}>
              {loc.name}
            </div>
          </div>
        ))}

        {selectedPin && (
          <div className="absolute bottom-6 left-6 right-6 md:left-auto md:w-80 bg-white p-4 rounded-2xl shadow-2xl border border-indigo-100 animate-slideUp z-30">
            <div className="flex justify-between items-start mb-2">
              <h3 className="font-bold text-gray-800">{selectedPin}</h3>
              <button onClick={() => setSelectedPin(null)} className="text-gray-400 hover:text-gray-600">
                <i className="fas fa-times"></i>
              </button>
            </div>
            <p className="text-xs text-gray-500 mb-4">Located in North Campus. Facilities: High-speed Wi-Fi, 24/7 access for final years.</p>
            <div className="flex gap-2">
              <button className="flex-1 bg-indigo-600 text-white py-2 rounded-lg text-sm font-semibold hover:bg-indigo-700 transition-colors">
                Get Directions
              </button>
              <button className="p-2 bg-indigo-50 text-indigo-600 rounded-lg hover:bg-indigo-100 transition-colors">
                <i className="fas fa-info-circle"></i>
              </button>
            </div>
          </div>
        )}

        <div className="absolute top-6 left-6 flex flex-col gap-2">
          <button className="w-10 h-10 bg-white rounded-xl shadow-md flex items-center justify-center text-gray-600 hover:bg-indigo-600 hover:text-white transition-colors">
            <i className="fas fa-plus"></i>
          </button>
          <button className="w-10 h-10 bg-white rounded-xl shadow-md flex items-center justify-center text-gray-600 hover:bg-indigo-600 hover:text-white transition-colors">
            <i className="fas fa-minus"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default CampusMap;
