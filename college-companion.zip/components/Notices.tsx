
import React, { useState } from 'react';
import { MOCK_NOTICES } from '../constants';

const Notices: React.FC = () => {
  const [filter, setFilter] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredNotices = MOCK_NOTICES.filter((notice) => {
    const matchesCategory = filter === 'All' || notice.category === filter;
    const matchesSearch = 
      notice.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      notice.content.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesCategory && matchesSearch;
  });

  const categories = ['All', 'Results', 'Exam-Fee', 'Academic', 'Administrative'];

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex gap-2 overflow-x-auto pb-2 w-full md:w-auto scrollbar-hide">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`shrink-0 px-5 py-2.5 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${
                filter === cat 
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' 
                  : 'bg-white text-gray-400 hover:bg-gray-100 hover:text-gray-600'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
        <div className="relative w-full md:w-72">
          <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-gray-300"></i>
          <input 
            type="text" 
            placeholder="Search notifications..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white border border-gray-100 rounded-2xl pl-11 pr-4 py-3 text-sm outline-none focus:ring-4 focus:ring-indigo-50/50 transition-all font-medium text-gray-600"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredNotices.length > 0 ? (
          filteredNotices.map((notice) => (
            <div key={notice.id} className="bg-white p-6 md:p-8 rounded-[32px] border border-gray-100 shadow-sm hover:shadow-md transition-all group relative overflow-hidden">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <span className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest ${
                    notice.category === 'Results' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' :
                    notice.category === 'Exam-Fee' ? 'bg-rose-50 text-rose-600 border border-rose-100' :
                    notice.category === 'Academic' ? 'bg-indigo-50 text-indigo-600 border border-indigo-100' :
                    'bg-gray-50 text-gray-500 border border-gray-100'
                  }`}>
                    {notice.category}
                  </span>
                  <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">
                    <i className="far fa-calendar-alt mr-1.5"></i>
                    {notice.date}
                  </span>
                </div>
                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="w-8 h-8 rounded-lg bg-gray-50 text-gray-400 hover:text-indigo-600 flex items-center justify-center transition-colors">
                    <i className="far fa-bookmark text-xs"></i>
                  </button>
                  <button className="w-8 h-8 rounded-lg bg-gray-50 text-gray-400 hover:text-indigo-600 flex items-center justify-center transition-colors">
                    <i className="fas fa-share-nodes text-xs"></i>
                  </button>
                </div>
              </div>

              <h3 className="text-xl font-black text-gray-900 mb-3 group-hover:text-indigo-600 transition-colors leading-tight">
                {notice.title}
              </h3>
              <p className="text-gray-500 text-sm leading-relaxed mb-6 font-medium line-clamp-2 group-hover:line-clamp-none transition-all duration-500">
                {notice.content}
              </p>

              <div className="pt-6 border-t border-gray-50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-black text-xs">
                    {notice.postedBy.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <p className="text-xs font-black text-gray-800 tracking-tight">{notice.postedBy}</p>
                    <p className="text-[9px] text-gray-400 font-bold uppercase tracking-widest">Authorized Source</p>
                  </div>
                </div>
                <button className="bg-gray-50 text-indigo-600 px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-600 hover:text-white transition-all active:scale-95 border border-indigo-50">
                  Full Details
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="bg-white p-20 rounded-[40px] border border-gray-100 text-center">
            <div className="w-20 h-20 bg-gray-50 text-gray-200 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="fas fa-search text-3xl"></i>
            </div>
            <h3 className="text-xl font-black text-gray-900">No Notifications</h3>
            <p className="text-gray-500 font-medium mt-2">No matching JNTUH notices were found for your search.</p>
            <button 
              onClick={() => {setSearchTerm(''); setFilter('All');}}
              className="mt-8 bg-indigo-50 text-indigo-600 px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-indigo-100 transition-all"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Notices;
