
import React from 'react';
import { MOCK_TIMETABLE } from '../constants';

const Timetable: React.FC = () => {
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden animate-fadeIn">
      <div className="p-6 border-b border-gray-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-800">Weekly Schedule</h2>
          <p className="text-gray-500 text-sm">Odd Semester 2024 • Computer Science Dept.</p>
        </div>
        <button className="flex items-center gap-2 bg-indigo-50 text-indigo-600 px-4 py-2 rounded-lg font-medium hover:bg-indigo-100 transition-colors">
          <i className="fas fa-download"></i>
          Export PDF
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-50 text-left border-b border-gray-100">
              <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Time Slot</th>
              {days.map(day => (
                <th key={day} className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">{day}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {['09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM'].map((slot) => (
              <tr key={slot} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-8 align-top">
                  <span className="font-bold text-gray-600 text-sm">{slot}</span>
                </td>
                {days.map((day) => {
                  const classAtSlot = MOCK_TIMETABLE.find(t => t.day === day && t.startTime === slot);
                  return (
                    <td key={`${day}-${slot}`} className="px-3 py-4 min-w-[160px]">
                      {classAtSlot ? (
                        <div className="bg-indigo-50 border-l-4 border-indigo-500 p-3 rounded-r-xl group cursor-pointer transition-transform hover:scale-105">
                          <p className="font-bold text-indigo-900 text-sm leading-tight mb-1">{classAtSlot.subject}</p>
                          <div className="flex items-center gap-2 text-indigo-600 text-xs mt-2">
                            <i className="fas fa-map-marker-alt"></i>
                            <span>{classAtSlot.room}</span>
                          </div>
                          <div className="flex items-center gap-2 text-indigo-600/70 text-xs mt-1">
                            <i className="fas fa-user-tie"></i>
                            <span className="truncate">{classAtSlot.instructor}</span>
                          </div>
                        </div>
                      ) : (
                        <div className="h-full w-full border border-dashed border-gray-200 rounded-xl min-h-[60px]"></div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Timetable;
