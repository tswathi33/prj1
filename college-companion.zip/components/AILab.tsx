
import React, { useState, useRef } from 'react';
import { generateImage, summarizeAcademicContent } from '../services/geminiService';

const AILab: React.FC = () => {
  const [imagePrompt, setImagePrompt] = useState('');
  const [imageSize, setImageSize] = useState<"1K" | "2K" | "4K">("1K");
  const [generatedImageUrl, setGeneratedImageUrl] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  
  const [analysisResult, setAnalysisResult] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleGenerateImage = async () => {
    if (!imagePrompt.trim()) return;
    setIsGenerating(true);
    try {
      const url = await generateImage(imagePrompt, imageSize);
      setGeneratedImageUrl(url);
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleFileAnalysis = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsAnalyzing(true);
    try {
      const result = await summarizeAcademicContent(file);
      setAnalysisResult(result);
    } catch (e) {
      setAnalysisResult("Error analyzing file. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn pb-20">
      <div className="mb-6">
        <h2 className="text-3xl font-bold text-[#1f1f1f]">AI Innovation Lab</h2>
        <p className="text-[#444746]">Research, Create, and Analyze with the power of Gemini 3 Pro.</p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        {/* Creation Hub */}
        <section className="bg-white p-8 rounded-[32px] border border-gray-100 shadow-sm flex flex-col">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center">
              <i className="fas fa-palette text-xl"></i>
            </div>
            <h3 className="text-xl font-bold">Visual Studio</h3>
          </div>

          <textarea 
            value={imagePrompt}
            onChange={(e) => setImagePrompt(e.target.value)}
            placeholder="Describe your creative project..."
            className="w-full bg-gray-50 border-none rounded-2xl px-5 py-4 outline-none focus:ring-2 focus:ring-indigo-100 transition-all min-h-[120px] mb-4"
          />

          <div className="flex flex-wrap items-center justify-between gap-4 mt-auto">
            <div className="flex gap-2">
              {(["1K", "2K", "4K"] as const).map(size => (
                <button
                  key={size}
                  onClick={() => setImageSize(size)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold ${imageSize === size ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-500'}`}
                >
                  {size}
                </button>
              ))}
            </div>
            <button 
              onClick={handleGenerateImage}
              disabled={isGenerating || !imagePrompt.trim()}
              className="bg-indigo-600 text-white px-8 py-3 rounded-2xl font-bold disabled:opacity-50 shadow-lg shadow-indigo-100"
            >
              {isGenerating ? <i className="fas fa-spinner animate-spin"></i> : 'Generate'}
            </button>
          </div>

          <div className="mt-6 aspect-square bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200 flex items-center justify-center overflow-hidden">
            {generatedImageUrl ? <img src={generatedImageUrl} className="w-full h-full object-cover" /> : <p className="text-gray-400 text-xs">Image Output</p>}
          </div>
        </section>

        {/* Intelligence Hub */}
        <section className="bg-white p-8 rounded-[32px] border border-gray-100 shadow-sm flex flex-col">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
              <i className="fas fa-microscope text-xl"></i>
            </div>
            <h3 className="text-xl font-bold">Paper Intelligence</h3>
          </div>

          <div 
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-emerald-200 rounded-2xl p-10 bg-emerald-50/20 text-center cursor-pointer hover:bg-emerald-50 transition-colors mb-6"
          >
            <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileAnalysis} accept=".pdf,.doc,.docx" />
            <i className="fas fa-cloud-upload-alt text-3xl text-emerald-500 mb-4"></i>
            <p className="font-bold text-emerald-700">Upload Academic Material</p>
            <p className="text-xs text-emerald-500/70 mt-1">PDF or Doc for deep analysis</p>
          </div>

          <div className="flex-1 bg-gray-50 rounded-2xl p-6 overflow-y-auto max-h-[400px]">
            {isAnalyzing ? (
              <div className="flex flex-col items-center justify-center h-full gap-4">
                <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin"></div>
                <p className="text-sm font-bold text-emerald-800 animate-pulse">Running Pro Analysis...</p>
              </div>
            ) : analysisResult ? (
              <div className="prose prose-sm max-w-none text-gray-700">
                <div className="whitespace-pre-wrap">{analysisResult}</div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-gray-400 text-center opacity-50">
                <i className="fas fa-file-alt text-4xl mb-4"></i>
                <p className="text-sm font-medium">Ready to summarize papers</p>
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};

export default AILab;
