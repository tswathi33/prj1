
import React, { useState } from 'react';
import { JNTUH_REGULATIONS, SYLLABUS_DATABASE } from '../services/jntuhData';

const JNTUHExplorer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'regulations' | 'syllabus'>('regulations');
  const [selectedReg, setSelectedReg] = useState(JNTUH_REGULATIONS[0]);
  const [branch, setBranch] = useState('CSE');
  const [semester, setSemester] = useState('2-1');

  return (
    <div className="space-y-6 animate-fadeIn pb-24">
      <div className="bg-white p-2 rounded-[32px] border border-gray-100 shadow-sm flex items-center max-w-md">
        <button 
          onClick={() => setActiveTab('regulations')}
          className={`flex-1 py-3 rounded-[24px] text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'regulations' ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-400'}`}
        >
          Regulations
        </button>
        <button 
          onClick={() => setActiveTab('syllabus')}
          className={`flex-1 py-3 rounded-[24px] text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'syllabus' ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-400'}`}
        >
          Syllabus Hub
        </button>
      </div>

      {activeTab === 'regulations' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 space-y-4">
            {JNTUH_REGULATIONS.map(reg => (
              <button 
                key={reg.code}
                onClick={() => setSelectedReg(reg)}
                className={`w-full p-6 rounded-[32px] border text-left transition-all ${selectedReg.code === reg.code ? 'border-indigo-600 bg-indigo-50/50 ring-4 ring-indigo-50' : 'border-gray-100 bg-white hover:border-indigo-200'}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xl font-black text-indigo-900">{reg.code}</span>
                  <i className="fas fa-chevron-right text-indigo-300"></i>
                </div>
                <p className="text-sm font-bold text-gray-600">{reg.name}</p>
              </button>
            ))}
          </div>
          
          <div className="lg:col-span-2 bg-white p-8 rounded-[40px] border border-gray-100 shadow-sm space-y-8">
            <div className="border-b border-gray-50 pb-6">
              <h2 className="text-2xl font-black text-gray-900">{selectedReg.name} Official Rules</h2>
              <p className="text-indigo-600 font-bold text-xs uppercase mt-1">JNTU Hyderabad Academic Council</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Attendance Rule</p>
                <p className="text-sm font-bold text-gray-700 leading-relaxed">{selectedReg.attendanceRule}</p>
              </div>
              <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Grace Marks Policy</p>
                <p className="text-sm font-bold text-gray-700 leading-relaxed">{selectedReg.graceMarks}</p>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-black text-gray-800">Promotion Rules (Credit Based)</h3>
              <div className="space-y-3">
                {Object.entries(selectedReg.promotionRules).map(([key, rule]) => (
                  <div key={key} className="flex gap-4 p-5 bg-indigo-50/30 rounded-2xl border border-indigo-100">
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-indigo-600 shrink-0 shadow-sm">
                      <i className="fas fa-arrow-up-right-from-square text-xs"></i>
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-indigo-600 uppercase mb-1">{key.replace('toYear', 'Promote to Year ')}</p>
                      <p className="text-sm font-bold text-gray-700">{rule}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          <div className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm flex flex-wrap gap-4">
            <select 
              value={branch} 
              onChange={(e) => setBranch(e.target.value)}
              className="bg-gray-50 border-none rounded-2xl px-6 py-3 text-sm font-bold text-gray-700 outline-none focus:ring-4 focus:ring-indigo-50"
            >
              <option>CSE</option>
              <option>ECE</option>
              <option>IT</option>
            </select>
            <select 
              value={semester} 
              onChange={(e) => setSemester(e.target.value)}
              className="bg-gray-50 border-none rounded-2xl px-6 py-3 text-sm font-bold text-gray-700 outline-none focus:ring-4 focus:ring-indigo-50"
            >
              {['1-1', '1-2', '2-1', '2-2', '3-1', '3-2', '4-1', '4-2'].map(s => <option key={s}>{s}</option>)}
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {SYLLABUS_DATABASE[branch]?.[semester]?.map(sub => (
              <div key={sub.code} className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-sm group hover:border-indigo-600 transition-all">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <span className="text-[10px] font-black text-indigo-600 bg-indigo-50 px-2 py-1 rounded mb-2 inline-block uppercase">{sub.code}</span>
                    <h3 className="text-xl font-black text-gray-900">{sub.name}</h3>
                  </div>
                  <div className="w-12 h-12 bg-gray-50 rounded-2xl flex flex-col items-center justify-center border border-gray-100">
                    <span className="text-sm font-black text-indigo-600">{sub.credits}</span>
                    <span className="text-[8px] font-black text-gray-400 uppercase">Cred</span>
                  </div>
                </div>

                <div className="space-y-4 mb-8">
                  {sub.units.map(unit => (
                    <div key={unit.unitNumber} className="relative pl-6 before:absolute before:left-0 before:top-2 before:w-1.5 before:h-1.5 before:bg-indigo-600 before:rounded-full before:shadow-sm">
                      <p className="text-xs font-black text-gray-800 uppercase tracking-tight">Unit {unit.unitNumber}: {unit.title}</p>
                      <p className="text-[10px] text-gray-400 mt-1 line-clamp-1">{unit.topics.join(' • ')}</p>
                    </div>
                  ))}
                </div>

                <div className="pt-6 border-t border-gray-50">
                  <button className="w-full bg-gray-50 text-indigo-600 py-3 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-indigo-600 hover:text-white transition-all">
                    Generate Study Plan
                  </button>
                </div>
              </div>
            )) || (
              <div className="col-span-full py-20 bg-white rounded-[40px] border-2 border-dashed border-gray-100 text-center">
                <i className="fas fa-folder-open text-4xl text-gray-200 mb-4"></i>
                <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">Syllabus Data for this branch coming soon.</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default JNTUHExplorer;
